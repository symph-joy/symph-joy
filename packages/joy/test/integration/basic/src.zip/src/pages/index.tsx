import React from "react";
import {add} from "../../util/calc";

function HomePage() {
  return <div>aaWelcome to Joy， add(1,2)=:{add(1 , 1)}</div>
}

export default HomePage
