import react from 'react'
import {Controller, Inject, ReactController} from "@symph/tempo";
import {HelloModel} from "../models/HelloModel";



@Controller()
export default class HelloController extends ReactController {

  @Inject(HelloModel)
  private helloModel: HelloModel;

  renderView() {
    const {status, count} = this.helloModel.state;
    return (
      <div>
        <div data-testid="status">a message: {status}</div>
        <div data-testid="count">total count: {count}</div>
        <button onClick={()=> this.helloModel.add(1)} >add 1</button>
      </div>
    );
  }
}

