import react from 'react'
function HomePage() {
  return <div>news list</div>
}

export default HomePage
