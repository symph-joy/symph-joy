import react from 'react'
import {add} from "../../../util/calc";
function HomePage() {
  return <div>news index ${add(1 , 2)}</div>
}

export default HomePage
