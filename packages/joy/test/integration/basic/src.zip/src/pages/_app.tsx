import {TempoFactory} from "@symph/tempo";
import {Component, useEffect, useState} from "react";

export default function MyApp({ Component, pageProps }: any) {
  const [{App}, setApp] = useState<any>({})
  useEffect( () => {
    const initApp = async () => {
      const app = await TempoFactory.create({});
      const _App = app.start();
      setApp({App: _App})
    }
    initApp()
  }, [])

  if(!App){
    return 'loading...'
  }
  return(
    <App>
      sss
    <Component {...pageProps} />
  </App>)
}
