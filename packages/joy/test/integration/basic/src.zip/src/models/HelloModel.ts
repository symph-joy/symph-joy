import {Model, ReactModel} from "@symph/tempo";

@Model()
export class HelloModel extends ReactModel<{ status: string, count: number }> {

  getInitState(): { status: string; count: number } {
    return {status: "hello joy", count: 1};
  }

  add(num: number){
    this.setState({count: this.state.count + num})
  }
}
