import {push_uniq} from "terser";

export function getRoutes() {
  const routes = [
    {
      "path": "/a/hello",
      "exact": true,
      "component": require('@/pages/a/hello.tsx').default
    },
    {
      "path": "/",
      "exact": true,
      "component": require('@/pages/index.tsx').default
    }
  ];


  return routes;
}


// export interface ServerRoutes{
//
// }

export class FsRouter {
  public getRoutes() {

    const routes = [
      {
        "path": "/a/hello",
        "exact": true,
        "component": require('@/pages/a/hello.tsx').default
      },
      {
        "path": "/",
        "exact": true,
        "component": require('@/pages/index.tsx').default
      }
    ];

    return  routes

  }
}
